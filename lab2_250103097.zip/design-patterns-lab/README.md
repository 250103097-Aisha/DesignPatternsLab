# Practical Design Patterns: Applied Engineering Lab

Five individual Java SE 8+ examples based on the supplied lab handout. **No Maven, Gradle, or external dependencies.** Each public class/interface lives in its own Java file.

| Task | Patterns | Entry point |
|---|---|---|
| 1 Secure data exporter | Strategy + Decorator | `task1.Task1Runner` |
| 2 Cached stock ticker | Adapter + Proxy | `task2.Task2Runner` |
| 3 Multi-channel alerts | Bridge + Strategy | `task3.Task3Runner` |
| 4 Currency/fees checkout | Adapter + Decorator | `task4.Task4Runner` |
| 5 Protected multi-cloud assets | Bridge + Proxy | `task5.Task5Runner` |

## Run in IntelliJ IDEA

1. Open this folder as a Java project.
2. Set Project SDK to JDK 8 or higher.
3. Right-click `src` > Mark Directory as > Sources Root (if needed).
4. Open any `TaskNRunner.java` and click the green Run arrow beside `main`.

## Compile and run in Terminal (macOS/Linux)

```bash
mkdir -p out
javac -encoding UTF-8 -d out src/task*/*.java
java -cp out task1.Task1Runner
java -cp out task2.Task2Runner
java -cp out task3.Task3Runner
java -cp out task4.Task4Runner
java -cp out task5.Task5Runner
java -cp out tests.VerificationTests
```

## What to demonstrate

- **Task 1:** Strategy chooses JSON/CSV; decorators wrap the export chain (the inner header is Base64 encoded by the outer layer in the provided runner).
- **Task 2:** Adapter parses `BID` and `ASK`; proxy prints network fetch, then cache hit, then network fetch after 1.6 seconds.
- **Task 3:** Bridge allows email/SMS channels; Strategy blocks low-severity alerts after hours but allows severity 5 emergencies.
- **Task 4:** `100 GBP × 1.25 = $125`; `$125 + $5 + $15 = $145`; `round($145 × 1.085, 2) = $157.33`.
- **Task 5:** Admin proxy allows S3 access; guest proxy refuses NFS access without reading a blob.

## Notes about the assignment PDF

The PDF contains inconsistencies between its high-level specifications and the supplied skeleton/immutable runners. This implementation follows the **provided Java runners and concrete skeleton behavior** where they conflict: e.g., Task 1 `=== METADATA HEADER ===` and `[BASE64_CIPHERTEXT:...]`, Task 3 `processAlert`, Task 5 `getStorageType`.

The Task 1 PDF expected-output section visibly truncates the Base64 line and reports `236 bytes`, which is not consistent with running its provided JSON-building code together with its header/footer and Base64 wrappers. This implementation prints the complete actual payload and byte count. Also, Base64 is encoding, **not cryptographic encryption**, and the sample SHA-256 text is only a simulated integrity marker.

The task 2 expected cache age (2 ms) is timing dependent and will vary by computer.

## Git submission

```bash
git init
git add .gitignore README.md src tests
git commit -m "Implement five practical Java design pattern labs"
git branch -M main
git remote add origin YOUR_REPOSITORY_URL
git push -u origin main
```

For strict progressive commits, commit each `src/taskN` after completing/verifying it, rather than committing all five together.
